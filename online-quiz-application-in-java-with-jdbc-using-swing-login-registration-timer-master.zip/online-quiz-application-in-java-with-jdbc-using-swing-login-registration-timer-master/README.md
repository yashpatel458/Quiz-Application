
# Online SY QUIZ Application written in java with jdbc using swing components
## Features
- Login.
- Registration.
- Offline mode(for testing purposes).
- Quiz timer.

> Note: While in  Offline mode it accepts any username and password but registration does not works.
## Requirements:
- Java 14
- IntelliJ IDE
- MySQL(We have used MySql Workbench to Create tables).

## MySql Column Names:

ID
full_name
user_name
g_mail
passwd

## Created by:

19DCS103 SMIT PATEL
19DCS106 YASH PATEL
